# Landing Page - Nathalia Abrell

Landing page profissional para Nathalia Abrell, Mentora de Negócios e Especialista em Vendas.

## 🚀 Tecnologias

- **Next.js 14** - Framework React
- **TypeScript** - Tipagem estática
- **Tailwind CSS** - Estilização moderna
- **Lucide React** - Ícones modernos

## 🎨 Características

- Design moderno e responsivo
- Cor verde como tema principal
- Seções otimizadas:
  - Hero com call-to-action
  - Sobre a mentora
  - Serviços oferecidos
  - Resultados e depoimentos
  - Call-to-action final
- Integração com Instagram
- Links para WhatsApp
- Performance otimizada

## 📦 Instalação

```bash
npm install
```

## 🏃 Executar

Modo desenvolvimento:
```bash
npm run dev
```

Build de produção:
```bash
npm run build
npm start
```

A aplicação estará disponível em `http://localhost:3000`

## 📱 Contato

- Instagram: [@nathaliaabrell](https://www.instagram.com/nathaliaabrell/)
- WhatsApp: (atualizar número)

## 📝 Notas

- Personalizar o número de WhatsApp na linha 332 do arquivo `app/page.tsx`
- Adicionar imagens reais se necessário
- Ajustar cores se precisar personalizar mais

---

Desenvolvido com ❤️ para Nathalia Abrell
