'use client'

import { useState } from 'react'
import { Instagram, Mail, MessageCircle, ArrowRight, CheckCircle, Star, TrendingUp, Users, Target, Zap } from 'lucide-react'

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <main className="min-h-screen">
      {/* Header/Navigation */}
      <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm shadow-sm z-50">
        <nav className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="text-2xl font-bold text-gradient">Nathalia Abrell</div>
            <div className="hidden md:flex gap-6">
              <a href="#sobre" className="text-gray-700 hover:text-primary-600 transition">Sobre</a>
              <a href="#servicos" className="text-gray-700 hover:text-primary-600 transition">Serviços</a>
              <a href="#resultados" className="text-gray-700 hover:text-primary-600 transition">Resultados</a>
              <a href="#contato" className="text-gray-700 hover:text-primary-600 transition">Contato</a>
            </div>
            <a 
              href="#contato" 
              className="hidden md:block bg-primary-600 text-white px-6 py-2 rounded-full hover:bg-primary-700 transition"
            >
              Fale Comigo
            </a>
            <button 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <div className="w-6 h-5 flex flex-col justify-between">
                <span className="w-full h-0.5 bg-gray-700"></span>
                <span className="w-full h-0.5 bg-gray-700"></span>
                <span className="w-full h-0.5 bg-gray-700"></span>
              </div>
            </button>
          </div>
          
          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="md:hidden mt-4 pb-4 flex flex-col gap-3">
              <a href="#sobre" className="text-gray-700 hover:text-primary-600 transition" onClick={() => setIsMenuOpen(false)}>Sobre</a>
              <a href="#servicos" className="text-gray-700 hover:text-primary-600 transition" onClick={() => setIsMenuOpen(false)}>Serviços</a>
              <a href="#resultados" className="text-gray-700 hover:text-primary-600 transition" onClick={() => setIsMenuOpen(false)}>Resultados</a>
              <a href="#contato" className="text-gray-700 hover:text-primary-600 transition" onClick={() => setIsMenuOpen(false)}>Contato</a>
            </div>
          )}
        </nav>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 bg-gradient-to-br from-primary-50 via-white to-primary-50">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block bg-primary-100 text-primary-700 px-4 py-2 rounded-full text-sm font-semibold mb-6">
                ✨ Mentora de Negócios
              </div>
              <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                Transforme Suas <span className="text-gradient">Vendas</span> e Alcance Resultados Extraordinários
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Sou Nathalia Abrell, especialista em vendas e mentora de negócios. Ajudo empreendedores e empresas a alcançarem seu máximo potencial através de estratégias comprovadas.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <a 
                  href="#contato" 
                  className="bg-primary-600 text-white px-8 py-4 rounded-full font-semibold hover:bg-primary-700 transition flex items-center justify-center gap-2 group"
                >
                  Quero Impulsionar Minhas Vendas
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition" />
                </a>
                <a 
                  href="https://www.instagram.com/nathaliaabrell/" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="border-2 border-primary-600 text-primary-600 px-8 py-4 rounded-full font-semibold hover:bg-primary-50 transition flex items-center justify-center gap-2"
                >
                  <Instagram className="w-5 h-5" />
                  Siga no Instagram
                </a>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-3xl bg-gradient-to-br from-primary-400 to-primary-600 p-1">
                <div className="w-full h-full bg-white rounded-3xl flex items-center justify-center">
                  <div className="text-center p-8">
                    <div className="w-32 h-32 mx-auto mb-4 bg-gradient-to-br from-primary-400 to-primary-600 rounded-full flex items-center justify-center">
                      <Target className="w-16 h-16 text-white" />
                    </div>
                    <p className="text-2xl font-bold text-gray-800">8.4K+</p>
                    <p className="text-gray-600">Seguidores no Instagram</p>
                  </div>
                </div>
              </div>
              {/* Floating Stats */}
              <div className="absolute -top-6 -right-6 bg-white rounded-2xl shadow-xl p-4 hidden lg:block">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-primary-600" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-800">+200%</p>
                    <p className="text-sm text-gray-600">Crescimento</p>
                  </div>
                </div>
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-4 hidden lg:block">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-primary-600" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-800">500+</p>
                    <p className="text-sm text-gray-600">Clientes</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sobre Section */}
      <section id="sobre" className="py-20 px-4 bg-white">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-4xl font-bold mb-6">Quem é Nathalia Abrell?</h2>
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Sou apaixonada por vendas e negócios! Com anos de experiência no mercado, desenvolvi metodologias exclusivas que já transformaram a realidade de centenas de empreendedores.
          </p>
          <p className="text-lg text-gray-600 mb-12 leading-relaxed">
            Minha missão é simples: ajudar você a dominar as estratégias de vendas que realmente funcionam, aumentar seu faturamento e construir um negócio próspero e sustentável.
          </p>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-6">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary-100 rounded-full flex items-center justify-center">
                <Target className="w-8 h-8 text-primary-600" />
              </div>
              <h3 className="font-bold text-xl mb-2">Foco em Resultados</h3>
              <p className="text-gray-600">Estratégias práticas e aplicáveis que geram resultados reais</p>
            </div>
            <div className="p-6">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary-100 rounded-full flex items-center justify-center">
                <Zap className="w-8 h-8 text-primary-600" />
              </div>
              <h3 className="font-bold text-xl mb-2">Metodologia Própria</h3>
              <p className="text-gray-600">Sistema exclusivo testado e validado</p>
            </div>
            <div className="p-6">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary-100 rounded-full flex items-center justify-center">
                <Users className="w-8 h-8 text-primary-600" />
              </div>
              <h3 className="font-bold text-xl mb-2">Acompanhamento Personalizado</h3>
              <p className="text-gray-600">Suporte individual para o seu crescimento</p>
            </div>
          </div>
        </div>
      </section>

      {/* Serviços Section */}
      <section id="servicos" className="py-20 px-4 bg-gray-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Como Posso Te Ajudar?</h2>
            <p className="text-xl text-gray-600">Soluções personalizadas para impulsionar seu negócio</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Serviço 1 */}
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition">
              <div className="w-14 h-14 bg-primary-100 rounded-full flex items-center justify-center mb-6">
                <TrendingUp className="w-7 h-7 text-primary-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Consultoria em Vendas</h3>
              <p className="text-gray-600 mb-6">
                Análise completa do seu processo de vendas com identificação de gargalos e oportunidades de crescimento.
              </p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-primary-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Diagnóstico personalizado</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-primary-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Plano de ação estratégico</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-primary-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Acompanhamento de resultados</span>
                </li>
              </ul>
            </div>

            {/* Serviço 2 */}
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition border-2 border-primary-500 relative">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                Mais Popular
              </div>
              <div className="w-14 h-14 bg-primary-100 rounded-full flex items-center justify-center mb-6">
                <Users className="w-7 h-7 text-primary-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Mentoria Individual</h3>
              <p className="text-gray-600 mb-6">
                Acompanhamento próximo e personalizado para transformar você em um especialista em vendas.
              </p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-primary-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Sessões 1:1 semanais</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-primary-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Material exclusivo</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-primary-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Suporte via WhatsApp</span>
                </li>
              </ul>
            </div>

            {/* Serviço 3 */}
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition">
              <div className="w-14 h-14 bg-primary-100 rounded-full flex items-center justify-center mb-6">
                <Target className="w-7 h-7 text-primary-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Treinamento de Equipes</h3>
              <p className="text-gray-600 mb-6">
                Capacitação completa da sua equipe de vendas com técnicas e ferramentas modernas.
              </p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-primary-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Workshops práticos</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-primary-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Desenvolvimento de habilidades</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-primary-600 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">Certificação da equipe</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Resultados/Social Proof Section */}
      <section id="resultados" className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Resultados que Falam por Si</h2>
            <p className="text-xl text-gray-600">Veja o que meus clientes alcançaram</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-16">
            <div className="text-center">
              <div className="text-5xl font-bold text-gradient mb-2">500+</div>
              <p className="text-gray-600 text-lg">Clientes Atendidos</p>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-gradient mb-2">200%</div>
              <p className="text-gray-600 text-lg">Crescimento Médio</p>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-gradient mb-2">8.4K+</div>
              <p className="text-gray-600 text-lg">Seguidores</p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Depoimento 1 */}
            <div className="bg-gray-50 rounded-2xl p-8">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-primary-500 text-primary-500" />
                ))}
              </div>
              <p className="text-gray-700 mb-6 italic">
                "A mentoria da Nathalia transformou completamente minha abordagem de vendas. Em 3 meses, dobrei meu faturamento!"
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary-200 rounded-full flex items-center justify-center">
                  <span className="font-bold text-primary-700">MR</span>
                </div>
                <div>
                  <p className="font-semibold">Maria Rodrigues</p>
                  <p className="text-sm text-gray-600">Empreendedora Digital</p>
                </div>
              </div>
            </div>

            {/* Depoimento 2 */}
            <div className="bg-gray-50 rounded-2xl p-8">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-primary-500 text-primary-500" />
                ))}
              </div>
              <p className="text-gray-700 mb-6 italic">
                "Profissional excepcional! As estratégias são práticas e os resultados aparecem rapidamente. Recomendo muito!"
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-primary-200 rounded-full flex items-center justify-center">
                  <span className="font-bold text-primary-700">JS</span>
                </div>
                <div>
                  <p className="font-semibold">João Silva</p>
                  <p className="text-sm text-gray-600">CEO Startup Tech</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contato" className="py-20 px-4 bg-gradient-to-br from-primary-600 to-primary-700 text-white">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Pronto para Transformar Suas Vendas?
          </h2>
          <p className="text-xl mb-12 opacity-90">
            Vamos conversar e encontrar a melhor estratégia para impulsionar seu negócio
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://wa.me/32471990930?text=Olá%20Nathalia!%20Gostaria%20de%20saber%20mais%20sobre%20sua%20mentoria" 
              target="_blank"
              rel="noopener noreferrer"
              className="bg-white text-primary-600 px-8 py-4 rounded-full font-semibold hover:bg-gray-100 transition flex items-center justify-center gap-2 text-lg"
            >
              <MessageCircle className="w-6 h-6" />
              Falar no WhatsApp
            </a>
            <a 
              href="https://www.instagram.com/nathaliaabrell/" 
              target="_blank"
              rel="noopener noreferrer"
              className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white/10 transition flex items-center justify-center gap-2 text-lg"
            >
              <Instagram className="w-6 h-6" />
              Instagram
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 bg-gray-900 text-white">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-2xl font-bold mb-4 text-gradient">Nathalia Abrell</h3>
              <p className="text-gray-400">
                Mentora de Negócios e Especialista em Vendas
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Links Rápidos</h4>
              <div className="flex flex-col gap-2">
                <a href="#sobre" className="text-gray-400 hover:text-primary-400 transition">Sobre</a>
                <a href="#servicos" className="text-gray-400 hover:text-primary-400 transition">Serviços</a>
                <a href="#resultados" className="text-gray-400 hover:text-primary-400 transition">Resultados</a>
                <a href="#contato" className="text-gray-400 hover:text-primary-400 transition">Contato</a>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Redes Sociais</h4>
              <div className="flex gap-4">
                <a 
                  href="https://www.instagram.com/nathaliaabrell/" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-primary-600 rounded-full flex items-center justify-center hover:bg-primary-700 transition"
                >
                  <Instagram className="w-5 h-5" />
                </a>
                <a 
                  href="mailto:contato@nathaliaabrell.com" 
                  className="w-10 h-10 bg-primary-600 rounded-full flex items-center justify-center hover:bg-primary-700 transition"
                >
                  <Mail className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} Nathalia Abrell. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </main>
  )
}
